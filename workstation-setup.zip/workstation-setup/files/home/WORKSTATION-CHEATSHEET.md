# Workstation Cheat Sheet

Installed by workstation-setup. Open any time with `ws-help` (works offline).
Press `q` to quit, `/` to search.

## Helper commands

| Command | What it does |
|---|---|
| `ws-help` | This cheat sheet |
| `ws-init` | Copy starter files (.clang-format, .clang-tidy, .clangd, pre-commit, CMakePresets.json, toolchain files) into the current project; never overwrites |
| `ws-devname list` | Show connected USB serial adapters and their stable names |
| `ws-devname add /dev/ttyUSB0 obc-console` | Name an adapter; it then always appears as `/dev/ws/obc-console` |
| `ws-devname remove obc-console` | Remove a name |
| `serial /dev/ws/obc-console 115200` | Open a serial console (exit: `Ctrl-t` then `q`) |
| `vcan-up` | Create virtual CAN bus `vcan0` for testing without hardware |
| `cppref` / `pydocs` / `cmakedocs` / `rustdocs` | Open local documentation in the browser |
| `z <part-of-dir>` | Jump to a frequently used directory |
| `Ctrl-R` | Fuzzy search command history |
| `Ctrl-T` | Fuzzy pick a file and insert its path |
| `lg` | lazygit: visual git in the terminal |

## Helix editor (`hx`)

Modes: `i` insert, `Esc` back to normal, `v` select mode. Helix selects
first, then acts: `w` then `d` deletes a word.

| Keys | Action |
|---|---|
| `Space f` | Find file (fuzzy) |
| `Space b` | Switch buffer |
| `Space /` | Search text in the whole project |
| `Space s` / `Space S` | Symbols in file / in workspace |
| `Space k` | Documentation for symbol under cursor |
| `gd` / `gr` / `gi` | Go to definition / references / implementation |
| `Ctrl-o` / `Ctrl-i` | Jump back / forward |
| `Space r` | Rename symbol everywhere |
| `Space a` | Code actions (quick fixes) |
| `Space d` / `Space D` | Errors and warnings in file / workspace |
| `]d` / `[d` | Next / previous error or warning |
| `Space c` or `Ctrl-c` | Toggle comment |
| `x` | Select line (repeat to extend) |
| `%` | Select whole file |
| `s` | Select regex matches within selection (multi-cursor) |
| `C` | Add cursor on next line |
| `,` | Back to a single cursor |
| `u` / `U` | Undo / redo |
| `Space y` / `Space p` | Copy to / paste from system clipboard |
| `Space ?` | Search all commands |
| `:w` `:q` `:wq` `:q!` | Save, quit, save and quit, quit without saving |
| `:format` | Format file (C/C++ are not auto-formatted on save) |
| `:sh <cmd>` | Run a shell command |

Check language support: `hx --health c` (also `cpp`, `python`, `rust`).

## Building C/C++ with CMake presets

After `ws-init` in a project with a CMakeLists.txt:

```bash
cmake --preset host-debug            # configure (strict warnings)
cmake --build --preset host-debug    # build
ctest --preset host-debug            # run unit tests

cmake --preset arm-cortex-m && cmake --build --preset arm-cortex-m
cmake --preset riscv        && cmake --build --preset riscv
cmake --preset host-sanitize         # AddressSanitizer + UBSan build
```

clangd reads `build/host-debug/compile_commands.json` (set in `.clangd`).
When working on target code, change `.clangd` to `build/arm-cortex-m`.

Target CPU flags belong in your project, e.g. for a Cortex-M4F:
`-mcpu=cortex-m4 -mthumb -mfloat-abi=hard -mfpu=fpv4-sp-d16 --specs=nano.specs`

## Coverage

```bash
cmake --preset coverage && cmake --build --preset coverage && ctest --preset coverage
mkdir -p coverage
gcovr --root . --html-details coverage/index.html build/coverage
```

## Static analysis

```bash
run-clang-tidy -p build/host-debug                 # clang-tidy, uses .clang-tidy
cppcheck --project=build/host-debug/compile_commands.json \
         --enable=warning,style,performance,portability
cppcheck --addon=misra ...                         # needs your licensed MISRA rule texts
scan-build cmake --build build/host-debug          # Clang static analyzer
flawfinder src/                                    # security-relevant patterns
lizard -C 10 src/                                  # functions with complexity > 10
cbmc file.c --function f --bounds-check --pointer-check   # bounded model checking
```

## Debugging on hardware

```bash
# Terminal 1: OpenOCD (examples: ST-Link + STM32F4, CMSIS-DAP + generic)
openocd -f interface/stlink.cfg -f target/stm32f4x.cfg
openocd -f interface/cmsis-dap.cfg -f target/<your-target>.cfg

# Terminal 2: GDB
gdb-multiarch build/arm-cortex-m/app.elf \
  -ex "target extended-remote :3333" -ex "monitor reset halt" -ex "load"
```

With several probes connected, select one by serial number in OpenOCD
(`adapter serial <serial>`). Rust/probe-rs: `probe-rs list`, then
`probe-rs run --chip <chip> target.elf`.

## Running target code in QEMU (no hardware)

```bash
qemu-system-arm -M lm3s6965evb -nographic -kernel app.elf        # Cortex-M3
qemu-system-riscv64 -M virt -bios none -nographic -kernel app.elf
qemu-system-sparc -M leon3_generic -nographic -kernel app.elf    # LEON3
# Add  -s -S  to wait for GDB on port 1234:  gdb-multiarch app.elf -ex "target remote :1234"
# Add  -semihosting-config enable=on,target=native  for semihosting output
```

## Serial and CAN

```bash
ws-devname list                       # what is connected
serial /dev/ws/obc-console 115200     # console (Ctrl-t q to exit)
ls -l /dev/serial/by-id/               # built-in stable (long) names

vcan-up                                # virtual CAN bus vcan0
candump vcan0                          # watch traffic
cansend vcan0 123#DEADBEEF             # send a frame
```

Named devices live in `/etc/udev/rules.d/70-workstation-devices.rules`.

## Python (offline)

Package managers work only from local caches (no internet at runtime):

```bash
uv venv && source .venv/bin/activate
uv pip install numpy pytest spacepackets       # served from the local wheelhouse
ruff check . && ruff format .                  # lint and format
basedpyright                                   # type check
```

Available offline: see `ls ~/.local/share/workstation/wheelhouse`.
To deliberately fetch something new (internal mirror, approved by IT):
`UV_OFFLINE=0 uv pip install <pkg>`

## Rust (offline)

```bash
cargo new my-crate && cd my-crate
cargo add heapless                    # from the local crate cache
cargo build --target thumbv7em-none-eabihf
cargo clippy                          # lints
```

To deliberately fetch something new: `CARGO_NET_OFFLINE=false cargo update`

## Containers (offline)

```bash
podman images                                   # images available offline
distrobox create -n lts -i docker.io/library/ubuntu:latest
distrobox enter lts                             # isolated environment, same home dir
```

Images are never pulled implicitly. An explicit `podman pull` still works.
Images for other or older systems (e.g. a project's heritage build
environment) are added deliberately in OFFLINE_CONTAINER_IMAGES.

## Git

```bash
lg                          # lazygit
git log --oneline --graph   # history
pre-commit install          # once per clone, after ws-init
pre-commit run --all-files  # check everything now
```

## Offline documentation

| Command | Content |
|---|---|
| `cppref` | C and C++ language and standard library (cppreference) |
| `pydocs` | Python documentation |
| `cmakedocs` | CMake reference |
| `rustdocs` | Rust standard library |
| `man 3 memcpy` | C library function |
| `man 3posix pthread_create` | POSIX specification |
| `info gdb` | GDB manual |
| `tldr <command>` | Practical examples |

## Workstation maintenance

Run these from the setup folder:

```bash
./setup.sh --check       # preview what setup would do (changes nothing)
./setup.sh --self-test   # verify toolchains and the no-cloud policy
./setup.sh --manifest    # list all installed software and versions
./setup.sh --lock        # pin current versions (commit workstation.lock)
./setup.sh --upgrade     # move to the newest stable versions, then --lock again
```

Each install run leaves `~/workstation-undo-<timestamp>.sh` (reverses changes),
`~/workstation-manifest-latest.txt` and a log file in your home directory.
Installed APT packages can be reverted with `apt history-list` and
`sudo apt history-undo <ID>` (APT 3 and later; otherwise see
/var/log/apt/history.log).
