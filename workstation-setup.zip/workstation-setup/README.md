# workstation-setup

Sets up a workstation on the latest Ubuntu LTS release for software development, for work
and personal use: C/C++/Rust/Python toolchains, the Helix editor with
language servers, git tooling, static analysis, offline documentation and a
comfortable bash. Optional embedded tooling: ARM and RISC-V cross compilers,
QEMU, debug probe, serial and CAN tools. No installed tool contacts the
internet after installation.

## Quick start

Run as your normal user (not with sudo), from a logged-in desktop session:

```bash
sudo apt update
./setup.sh --check     # dry run: what would happen? changes nothing
./setup.sh             # install, configure, write manifest, run self-test
```

Then log out and back in, open a terminal and run `ws-help`.

## Commands

| Command | Purpose |
|---|---|
| `./setup.sh --check` | Dry run: package availability, conflicts, planned changes |
| `./setup.sh` | Full installation, then manifest and self-test |
| `./setup.sh --self-test` | Verify toolchains, offline caches and the no-cloud policy |
| `./setup.sh --manifest` | Write a full list of installed software and versions |
| `./setup.sh --lock` | Pin all non-APT versions and download checksums |
| `./setup.sh --upgrade` | Ignore pins, install the newest stable versions, self-test |

## Files

| Path | Purpose |
|---|---|
| `setup.sh` | The setup logic |
| `workstation.conf` | Switches, package lists, tool lists. Edit this. |
| `workstation.lock` | Pinned versions and checksums (created by `--lock`) |
| `workstation.Cargo.lock` | Pinned Rust crate versions (created by `--lock`) |
| `files/home/` | Config files installed into your home directory |
| `files/templates/` | Project starter files used by `ws-init` |
| `files/selftest/` | Sources compiled and run by the self-test |

## Team workflow (reproducible workstations)

1. One engineer runs `./setup.sh`, checks the self-test, then runs
   `./setup.sh --lock`.
2. Commit the whole folder, including `workstation.lock` and
   `workstation.Cargo.lock`, to version control.
3. Every other machine runs `./setup.sh` from that commit and gets the same
   versions of everything outside APT. Downloads whose checksum doesn't match
   the lock are refused.
4. To upgrade deliberately: run `./setup.sh --upgrade` on one machine, check
   the self-test, re-run `--lock`, review the diff, commit.

APT packages are not pinned (that would block Ubuntu security updates); each
machine's exact package versions are recorded in its manifest
(`~/workstation-manifest-latest.txt`), so two machines can be compared with
`diff`.

## Policies

**Versions.** Always the latest Ubuntu LTS release: the setup detects it
(offline, via distro-info) and warns on older or non-LTS releases. For
software with an LTS line, the newest LTS; otherwise the newest stable
release. Never betas, release candidates or nightlies. A lock file is a
deliberate snapshot of "newest at that time"; `--upgrade` moves forward.

**No cloud.** Downloading during installation is allowed. Afterwards, no tool
contacts external services: cloud-connected tools aren't installed, update
checks and telemetry are disabled, and uv/pip/cargo/podman work only from
local caches filled during installation (see `files/home/.bashrc.d/20-offline.sh`).
The self-test verifies this.

**Don't break Ubuntu.** No package is ever removed (`apt --no-remove`), no
package-owned config file is edited, and kernel, boot, coreutils and APT
sources are untouched. Every change is recorded in
`~/workstation-undo-<timestamp>.sh`.

**Checksums.** Files downloaded outside APT (installers, Helix, SPICE
kernels) are verified against SHA-256 values in `workstation.lock`. Without a
lock, checksums are recorded on first download (trust on first use) and
pinned by `--lock`. Compare them with the publisher's values if your process
requires it. Package managers (APT, cargo, uv/pip, npm) verify their own
downloads.

## Not included

Vendor or licensed tools: Gaisler toolchains for LEON (BCC/RCC), RTEMS (build
with the RTEMS Source Builder, ideally in a Distrobox container), VxWorks,
SEGGER J-Link software, Renode, MISRA rule texts for cppcheck.
