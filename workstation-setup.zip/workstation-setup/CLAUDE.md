# CLAUDE.md — context for Claude Code

This folder sets up an workstation on the latest Ubuntu LTS release for software
development, for work and personal use (the user's work is spacecraft flight
software, hence the optional embedded tooling). It was designed in a claude.ai conversation; this file
carries that context over.

## The user
- Spacecraft flight software engineer; languages: Python, C, C++, Rust,
  plus JSON/YAML/XML.
- Terminal beginner who chose a terminal editor: Helix (not Neovim).
- Wants to understand and control the setup; explain changes, don't just make them.

## Hard requirements (never violate)
1. **No cloud.** No installed tool may contact external services during
   normal use: no telemetry, update checks, online lookups, implicit
   downloads. Downloading DURING INSTALLATION is explicitly allowed.
   Cloud-connected tools (gh, schema-fetching JSON/YAML LSPs, snaps, ...)
   are never installed. Runtime enforcement: files/home/.bashrc.d/20-offline.sh,
   uv.toml, containers.conf, lazygit/tealdeer/npm/rustup settings.
2. **Don't break Ubuntu.** apt always with --no-remove; never edit
   package-owned config files (conffile prompts block unattended security
   updates); only NEW drop-in files in /etc; disable (never mask) services;
   no changes to kernel, boot, coreutils, architecture variants, APT sources.
3. **Everything reversible.** Every system/config change calls record_undo.

4. **Always the latest stable, long-term supported version** (decided by the
   user), for the OS and for software in general:
   - OS: the latest Ubuntu LTS release. Never hardcode a release: os_check
     detects it at runtime via distro-info's offline database and warns on
     older or non-LTS releases. Release-specific features (e.g. APT 3's
     history) must be optional or explained as "on newer APT".
   - Software with an LTS line (Node.js, Java, container base images, ...):
     the newest LTS. Software without one (Rust, Helix, ruff, uv, ...): the
     newest stable release. Never betas, RCs, nightlies.
   - Never hardcode version numbers as defaults. Empty = "newest stable,
     resolved at install time"; exact versions live only in the lock file.
   - Lock vs latest: the lock is a deliberate snapshot of "newest at that
     time" (needed for reproducible work machines). `./setup.sh --upgrade`
     ignores the pins, installs the newest versions and self-tests; then
     `--lock` re-pins. Without a lock, every install gets the newest.
   - Container images: ubuntu:latest (= newest LTS). Older images only as
     deliberate, pinned exceptions.
   - OPEN QUESTION (ask the user): when the Ubuntu archive ships an older but
     Canonical-supported version and upstream has a newer LTS/stable release
     (e.g. Node.js), which wins? Current code prefers the archive (security
     updates via apt for the release's lifetime, no extra package sources).
     Components the OS itself depends on (system Python, gcc, glibc,
     systemd) must ALWAYS stay the archive version under requirement 2.

Note: Claude Code itself is cloud-connected. Per requirement 1 it must not be
installed on the target workstation. Develop this repo on another machine,
and test in a disposable VM with the latest Ubuntu LTS.

## NEXT MAJOR TASK: generalize beyond flight software (decided by the user)

The user wants ONE setup usable for flight software work, other work, and
personal machines. Decisions:
- **No-cloud is strict on EVERY profile**, personal included. It is a fixed
  core policy, not a per-profile switch. Same for "don't break Ubuntu".
- **Scope stays as it is** for development: no new web / data science /
  DevOps modules.
- **Personal profile includes everyday desktop apps**, not only development.

### Definition of "no cloud" for inherently networked apps (PROPOSED: confirm with user)
Allowed: traffic the user directs to a destination the user chose (opening a
website, fetching mail from their own server, an explicit `podman pull`).
Not allowed: anything automatic or in the background: telemetry, update
checks, crash reports, sync, accounts, recommendations, automatic lookups
(album art, website icons, metadata), implicit downloads.

### Proposed design
1. **Neutral naming: DONE.** The user asked that a general setup not be
   named after flight software. Everything is renamed: project
   "workstation-setup", workstation.conf/.lock, commands ws-help, ws-init,
   ws-devname, named serial devices in /dev/ws/, data in
   ~/.local/share/workstation, home files workstation-*. Keep new names
   neutral; flight-software specifics belong only inside the embedded module.
2. **Modules** (config fragments with package lists, tool lists, home files,
   self-tests):
   - core: bash setup, Helix + LSPs, git tooling, Python/C/C++/Rust,
     offline docs, privacy hardening, offline caches, check/self-test/
     manifest/lock/undo machinery. Always on.
   - embedded (today's flight-software parts): cross compilers, QEMU,
     OpenOCD, serial/CAN, Wireshark, verification tools, SPICE, embedded
     templates (toolchain files, ARM/RISC-V presets).
   - desktop: everyday apps for the personal profile (see below).
3. **Profiles** select modules: profiles/work.conf (core + embedded),
   profiles/personal.conf (core + desktop; embedded optional).
   `./setup.sh --profile personal`. Remember the chosen profile in
   ~/.config/workstation/profile so --check/--self-test/--lock default to it.
4. **One lock per profile** (locks/<profile>.lock, locks/<profile>.Cargo.lock).
5. **Templates split**: generic (editorconfig, pre-commit, ruff,
   clang-format/tidy, host CMake presets) vs embedded (toolchain files,
   ARM/RISC-V presets, .clangd target note). `ws-init` / `ws-init --embedded`.
6. Self-tests: tag by module; skip when the module is off (needs_on already
   supports this). Extend t_nocloud_policy for every desktop app added.

### Desktop module: rules and candidates
- Debs from the Ubuntu archive only. No snaps, no Flatpak/Flathub (online
  stores with background refresh).
- Every app gets its background network features switched off, preferably
  via NEW system-wide policy/drop-in files (never edit package-owned files),
  and each setting gets a self-test check.
- Candidates (verify each on the current LTS, ask the user which they want):
  - LibreOffice (preinstalled; ensure online update check is off)
  - KeePassXC (offline password manager; disable update check and website
    icon downloads)
  - VLC or mpv (VLC: disable metadata/album-art network access)
  - GIMP, Inkscape
  - Déjà Dup backups to a local/external disk only (never cloud targets)
  - Spell-check dictionaries / LibreOffice language packs: ASK which languages
- Browser and email: Firefox is a snap on Ubuntu; Thunderbird may be too.
  Firefox/Thunderbird support enterprise policy files
  (e.g. /etc/firefox/policies/policies.json) that can disable telemetry,
  studies, Pocket, sponsored content, default-browser and update prompts.
  Check how the snap reads them on the current LTS and never overwrite an existing
  policies file. Whether to keep snaps at all is the user's/IT's decision.
- GNOME Online Accounts: leave unconfigured; consider a self-test warning if
  any online account is set up.

### Open questions for the user
- Confirm the "no cloud" definition above.
- Which everyday apps; which languages for spell-check and LibreOffice.
- Browser and email client: keep Firefox/Thunderbird snaps with policy
  hardening, or something else?

## Layout
- setup.sh — logic. Modes: (default) install, --check, --self-test,
  --manifest, --lock.
- workstation.conf — switches (`: "${X:=default}"`, env overrides), package
  arrays PKGS_*, tool lists. WHAT to install.
- workstation.lock — generated by --lock: exact versions + SHA-256 pins
  (sourced before the conf, so pins win). WHICH versions. Not committed yet.
- files/home/ — installed into ~ via install_file (keeps user-modified files
  unless FORCE_CONFIG=1).
- files/templates/ — project starter files, copied by `ws-init`.
- files/selftest/ — sources for self-test (bare-metal ARM/RISC-V semihosting
  programs for QEMU, GoogleTest and CMake-presets projects).

## Conventions in setup.sh
- `set -Eeuo pipefail`; each install step runs via `step` in a subshell so one
  failure doesn't abort the run; failures are summarized at the end.
- apt_install skips missing packages and records them (never fatal).
- write_config / install_file / record_undo / fetch_verified (SHA-256 TOFU,
  then pinned via lock) / add_to_groups / disable_units.
- Self-tests: functions t_*, run via run_test; exit 77 = SKIP (`skip`,
  `needs`, `needs_on`).

## Status
Tested in an Ubuntu 24.04 sandbox WITHOUT network or cross tools:
- bash -n on all shell files; all JSON/YAML/TOML parse.
- --check runs end to end (found a real NodeSource-vs-Ubuntu npm conflict).
- --self-test framework, --manifest and --lock run correctly.
- CRC test program compiles cleanly with -Wall -Wextra -Wpedantic -Wconversion.

Not yet run on a real Ubuntu LTS install: nothing has been verified against its
actual package archive.

## Open tasks (in order)
1. Run `shellcheck setup.sh files/home/.local/bin/ws-devname files/home/.bashrc.d/*.sh`
   and fix findings (wasn't available in the sandbox).
2. In a VM with the latest Ubuntu LTS: `sudo apt update && ./setup.sh --check`. Fix package
   names reported NOT AVAILABLE in workstation.conf.
3. Run `./setup.sh` in the VM (snapshot first), then `./setup.sh --self-test`.
4. Assumptions to verify on the real latest LTS (each written without being able to test):
   - containers.conf `[engine] pull_policy = "never"` is accepted by podman
     (cache_images removes the file again if `podman info` fails).
   - Helix tarball name helix-<ver>-x86_64-linux.tar.xz (only if Helix isn't in apt).
   - `clangd --check` returns non-zero when the file has errors.
   - QEMU semihosting tests (t_arm_qemu, t_riscv_qemu): vector table/startup,
     SYS_EXIT semantics (32-bit ARM passes the reason code directly; RV64 a
     pointer to a 2-word block).
   - Doc paths: cppreference under /usr/share/cppreference/doc/html/,
     POSIX man pages as section 3posix.
   - udev properties ID_VENDOR_ID / ID_MODEL_ID / ID_SERIAL_SHORT /
     ID_USB_INTERFACE_NUM on tty devices (ws-devname).
   - starship installer flags `-y -b <dir>`; uv versioned installer URL
     https://astral.sh/uv/<version>/install.sh.
5. When the VM run is clean: `./setup.sh --lock`, review, commit the folder
   to git with workstation.lock and workstation.Cargo.lock.

## Safety rules for Claude Code in this repo
- Do not run `./setup.sh` (install mode) on the development machine: it uses
  sudo and changes the system. `--check`, `--self-test`, `--manifest` are
  read-only; `--lock` only writes workstation.lock next to the script.
- Keep both policies above when changing anything; extend t_nocloud_policy
  when adding a tool that could phone home.
